from django.urls import path
from .views import UsuarioCreateView, LoginView, DashboardView, HomeView, usuario_logout, BalanceteCreateView, BalanceteDetailView, ReceitaCreateView, DespesaCreateView, MovimentacoesListView, BalanceteDeleteView
app_name='financas'

urlpatterns = [
    path("", HomeView.as_view(), name="home"),
    path("cadastro/", UsuarioCreateView.as_view(), name="cadastro"), 
    path("login/", LoginView.as_view(), name="login"), 
    path('dashboard/', DashboardView.as_view(), name='dashboard'),
    path("logout/", usuario_logout, name="logout"),
    path("cadastro-balancete/", BalanceteCreateView.as_view(), name="balancete_create"),
    path("balancete/<int:pk>/", BalanceteDetailView.as_view(), name="balancete_detail"),
    path("balancete/<int:balancete_id>/receita/", ReceitaCreateView.as_view(), name="receita_create"),
    path("balancete/<int:balancete_id>/despesa/", DespesaCreateView.as_view(), name="despesa_create"),
    path("movimentacoes/", MovimentacoesListView.as_view(), name="movimentacoes_list"),
    path("balancete/<int:pk>/delete/", BalanceteDeleteView.as_view(), name="balancete_delete"),


    
]
