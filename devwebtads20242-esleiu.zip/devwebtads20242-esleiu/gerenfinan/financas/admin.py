from django.contrib import admin
from .models import Balancete, Receita, Despesa, Usuario

admin.site.register(Balancete)
admin.site.register(Receita)
admin.site.register(Despesa)
admin.site.register(Usuario)
