from django.views.generic.edit import FormView
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import (
    TemplateView,
    ListView,
    CreateView,
    DetailView,
    DeleteView,
)
from .forms import UsuarioForm, LoginForm, BalanceteForm, ReceitaForm, DespesaForm
from .models import Usuario, Balancete, Receita, Despesa
from django.shortcuts import redirect
from django.contrib.auth import logout
from django.shortcuts import render, redirect, get_object_or_404


class HomeView(TemplateView):
    template_name = "home.html"


class UsuarioCreateView(FormView):
    template_name = "cadastro.html"
    form_class = UsuarioForm
    success_url = reverse_lazy("financas:login")

    def form_valid(self, form):
        usuario = form.save()
        messages.success(self.request, "Usuário cadastrado com sucesso!")
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, "Erro no cadastro. Verifique os dados.")
        return super().form_invalid(form)


class LoginView(FormView):
    template_name = "login.html"
    form_class = LoginForm
    success_url = reverse_lazy("financas:dashboard")

    def form_valid(self, form):
        username = form.cleaned_data.get("username")
        password = form.cleaned_data.get("password")

        user = authenticate(self.request, username=username, password=password)

        if user is not None:
            login(self.request, user)

            print(f"Usuário autenticado: {self.request.user.is_authenticated}")

            messages.success(self.request, "Login realizado com sucesso!")
            return super().form_valid(form)
        else:
            form.add_error(None, "Nome de usuário ou senha incorretos.")
            return self.form_invalid(form)


class DashboardView(LoginRequiredMixin, ListView):
    login_url = reverse_lazy("financas:login")
    template_name = "dashboard.html"
    model = Balancete
    context_object_name = "balancetes"

    def get_queryset(self):
        query = self.request.GET.get("q")
        if query:
            return Balancete.objects.filter(
                usuario=self.request.user, nome__icontains=query
            )
        return Balancete.objects.filter(usuario=self.request.user)


class BalanceteCreateView(LoginRequiredMixin, CreateView):
    model = Balancete
    form_class = BalanceteForm
    template_name = "balancete_form.html"
    success_url = reverse_lazy("financas:dashboard")

    def form_valid(self, form):
        form.instance.usuario = self.request.user
        return super().form_valid(form)


class BalanceteDetailView(LoginRequiredMixin, DetailView):
    model = Balancete
    template_name = "balancete_detail.html"
    context_object_name = "balancete"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        balancete = self.get_object()
        query = self.request.GET.get("q", "")

        if query:
            context["receitas"] = balancete.receitas.filter(descricao__icontains=query)
            context["despesas"] = balancete.despesas.filter(descricao__icontains=query)
        else:
            context["receitas"] = balancete.receitas.all()
            context["despesas"] = balancete.despesas.all()

        return context


class ReceitaCreateView(LoginRequiredMixin, CreateView):
    model = Receita
    form_class = ReceitaForm
    template_name = "receita_form.html"

    def form_valid(self, form):
        balancete = get_object_or_404(Balancete, id=self.kwargs["balancete_id"])
        form.instance.balancete = balancete
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy(
            "financas:balancete_detail", kwargs={"pk": self.object.balancete.id}
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["balancete"] = get_object_or_404(
            Balancete, id=self.kwargs["balancete_id"]
        )
        return context


class DespesaCreateView(LoginRequiredMixin, CreateView):
    model = Despesa
    form_class = DespesaForm
    template_name = "despesa_form.html"

    def form_valid(self, form):
        balancete = get_object_or_404(Balancete, id=self.kwargs["balancete_id"])
        form.instance.balancete = balancete
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy(
            "financas:balancete_detail", kwargs={"pk": self.object.balancete.id}
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["balancete"] = get_object_or_404(
            Balancete, id=self.kwargs["balancete_id"]
        )
        return context


class MovimentacoesListView(LoginRequiredMixin, ListView):
    template_name = "movimentacoes_list.html"
    context_object_name = "movimentacoes"

    def get_queryset(self):
        query = self.request.GET.get("q", "")

        receitas = Receita.objects.filter(balancete__usuario=self.request.user)
        despesas = Despesa.objects.filter(balancete__usuario=self.request.user)

        if query:
            receitas = receitas.filter(descricao__icontains=query)
            despesas = despesas.filter(descricao__icontains=query)

        for receita in receitas:
            receita.tipo = "Receita"
        for despesa in despesas:
            despesa.tipo = "Despesa"

        movimentacoes = list(receitas) + list(despesas)

        movimentacoes.sort(key=lambda x: x.data, reverse=True)

        return movimentacoes


class BalanceteDeleteView(DeleteView):
    model = Balancete
    success_url = reverse_lazy("financas:dashboard")

    def get(self, request, *args, **kwargs):
        """Evita que usuários acessem a página de deleção diretamente."""
        return self.post(request, *args, **kwargs)


def usuario_logout(request):
    logout(request)
    return redirect(reverse_lazy("financas:home"))
