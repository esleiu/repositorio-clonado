from django.db import models
from django.core.exceptions import ValidationError

from django.db.models import Sum
from django.utils import timezone
from django.contrib.auth.models import AbstractUser


class Usuario(AbstractUser):
    cpf = models.CharField(max_length=16, unique=True, verbose_name="CPF")

    def __str__(self):
        return self.username


class Balancete(models.Model):
    nome = models.CharField(max_length=50, verbose_name="Nome Balancete")
    data_criacao = models.DateField(auto_now_add=True, verbose_name="Data de Criação")
    usuario = models.ForeignKey(
        Usuario,
        on_delete=models.CASCADE,
        related_name="balancetes",
    )
    saldo = models.DecimalField(
        max_digits=10, decimal_places=2, default=0.0, verbose_name="Saldo"
    )

    def calcular_saldo(self):
        receitas = self.receitas.aggregate(total=Sum("valor"))["total"] or 0
        despesas = self.despesas.aggregate(total=Sum("valor"))["total"] or 0
        self.saldo = receitas - despesas
        self.save(update_fields=["saldo"])
        novo_saldo = receitas - despesas

        if self.saldo != novo_saldo:
            self.saldo = novo_saldo
            self.save(update_fields=["saldo"])

    class Meta:
        ordering = ["-data_criacao"]

    def __str__(self):
        return f"{self.nome} - Saldo {self.saldo}"


class Receita(models.Model):
    descricao = models.CharField(max_length=200, verbose_name="Descrição da Entrada")
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Valor")
    data = models.DateField(verbose_name="Data")
    balancete = models.ForeignKey(
        Balancete, on_delete=models.CASCADE, related_name="receitas"
    )

    def clean(self):
        if self.valor <= 0:
            raise ValidationError("O valor da receita deve ser maior que zero")
        if self.data > timezone.now().date():
            raise ValidationError("A data não pode ser no futuro")

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
        self.balancete.calcular_saldo()

    def __str__(self):
        return f"Receita: {self.descricao} - R$ {self.valor} - Data {self.data}"


class Despesa(models.Model):
    descricao = models.CharField(max_length=200, verbose_name="Descrição Despesa")
    valor = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Valor")
    data = models.DateField()
    balancete = models.ForeignKey(
        Balancete, on_delete=models.CASCADE, related_name="despesas"
    )
    foto_despesa = models.ImageField(
        upload_to="despesas/", blank=True, null=True, verbose_name="Foto Despesa"
    ) 

    def clean(self):
        if self.valor <= 0:
            raise ValidationError("O valor da despesa não deve conter sinal negativo")
        if self.data > timezone.now().date():
            raise ValidationError("A data da despesa não pode ser no futuro")

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
        self.balancete.calcular_saldo()

    def __str__(self):
        return f"Despesa {self.descricao} - R$ {self.valor} - Data {self.data}"


@staticmethod
def pesquisar_por_nome(nome):
    receitas = Receita.objects.filter(descricao__icontains=nome)
    despesas = Despesa.objects.filter(descricao__icontains=nome)
    return {"receitas": receitas, "despesas": despesas}
