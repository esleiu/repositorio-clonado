from django import forms
from django.contrib.auth.forms import UserCreationForm
from financas.models import Usuario, Balancete, Despesa, Receita


class UsuarioForm(UserCreationForm):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={"class": "input-field", "placeholder": "Seu nome de usuário..."}
        )
    )

    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={"class": "input-field", "placeholder": "Exemplo@gmail.com..."}
        )
    )

    cpf = forms.CharField(
        widget=forms.TextInput(
            attrs={"class": "input-field", "placeholder": "Seu CPF..."}
        )
    )

    password1 = forms.CharField(
        label="Senha",
        widget=forms.PasswordInput(
            attrs={"class": "input-field", "placeholder": "Digite sua senha..."}
        ),
    )

    password2 = forms.CharField(
        label="Confirme sua Senha",
        widget=forms.PasswordInput(
            attrs={"class": "input-field", "placeholder": "Confirme sua senha..."}
        ),
    )

    class Meta:
        model = Usuario
        fields = ["username", "email", "cpf", "password1", "password2"]

    def clean(self):
        cleaned_data = super().clean()
        senha = cleaned_data.get("password1")
        senha_confirm = cleaned_data.get("password2")

        if senha and senha_confirm and senha != senha_confirm:
            self.add_error("password2", "As senhas não conferem.")
        return cleaned_data


class LoginForm(forms.Form):
    username = forms.CharField(
        label="",
        widget=forms.TextInput(
            attrs={
                "class": "input-field",
                "placeholder": "Digite seu nome de usuário...",
            }
        ),
    )
    password = forms.CharField(
        label="",
        widget=forms.PasswordInput(
            attrs={"class": "input-field", "placeholder": "Digite sua senha..."}
        ),
    )


class BalanceteForm(forms.ModelForm):
    class Meta:
        model = Balancete
        fields = ["nome"]


class ReceitaForm(forms.ModelForm):
    class Meta:
        model = Receita
        fields = ["descricao", "valor", "data"]


class DespesaForm(forms.ModelForm):
    class Meta:
        model = Despesa
        fields = ["descricao", "valor", "data", "foto_despesa"]
